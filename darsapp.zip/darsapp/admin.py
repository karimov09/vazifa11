from django.contrib import admin

from .models import Sahifa, Category



admin.site.register(Sahifa)
admin.site.register(Category)