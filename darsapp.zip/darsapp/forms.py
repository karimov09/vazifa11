from django import forms
from .models import Sahifa

class SahifaForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(SahifaForm, self).__init__(*args, **kwargs)

        for field_name, field in self.fields.items():
            if field_name != 'is_going':
                field.widget.attrs["class"] = "form-control mb-3"

    class Meta:
        model = Sahifa
        fields = ["title", "body", "is_going", "category", "price", "contact_info"]  

class CategoryForm(forms.Form):
    name = forms.CharField(max_length=255)
    image = forms.ImageField()