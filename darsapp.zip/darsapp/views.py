from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from .models import Sahifa, Category
from .forms import SahifaForm


def home_page(request):
    sahifa_list = Sahifa.objects.filter(is_going=True).order_by("-started_at")
    return render(request, "index.html", {"sahifa_list": sahifa_list, "categories": Category.objects.all()})

def detail_page(request, pk):
    sahifa_item = get_object_or_404(Sahifa, pk=pk)
    sahifa_item.views_count += 1
    sahifa_item.save()
    return render(request, "detail.html", {"sahifa_item": sahifa_item})

def add_sahifa(request):
    form = SahifaForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        sahifa = form.save(commit=False)
        sahifa.user = request.user
        sahifa.save()
        return redirect("home_page")
    return render(request, "add_sahifa.html", {"form": form})

def login_view(request):
    form = AuthenticationForm(request, data=request.POST or None)
    if form.is_valid():
        login(request, form.get_user())
        return redirect("home_page")
    return render(request, "login.html", {"form": form})

def register_view(request):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect("home_page")
    return render(request, "register.html", {"form": form})

def logout_view(request):
    logout(request)
    return redirect("home_page")

def filter_by_category(request, category_name):
    sahifa_list = Sahifa.objects.filter(category__name=category_name, is_going=True).order_by("-started_at")
    return render(request, "index.html", {"sahifa_list": sahifa_list, "categories": Category.objects.all()})
