from django.urls import path
from . import views

urlpatterns = [
    path('', views.GroupListView.as_view(), name='group-list'), 
    path('group/<int:pk>/', views.GroupDetailView.as_view(), name='group-detail'),  
    path('group/create/', views.GroupCreateView.as_view(), name='group-create'), 
    path('group/<int:pk>/update/', views.GroupUpdateView.as_view(), name='group-update'),
    path('group/<int:pk>/delete/', views.GroupDeleteView.as_view(), name='group-delete'),  
]